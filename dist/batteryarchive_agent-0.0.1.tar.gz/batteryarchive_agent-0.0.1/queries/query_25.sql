/*
Name: Cycle Test DD
Data source: 1
Created By: admin
Last Update At: 2022-03-05T20:38:33.294Z
Visualizations: [{'id': 29, 'type': 'TABLE', 'name': 'Table', 'description': '', 'options': {}, 'updated_at': '2022-02-27T21:57:13.704Z', 'created_at': '2022-02-27T21:57:13.704Z'}]
*/

select cell_id from cycle_metadata order by cell_id