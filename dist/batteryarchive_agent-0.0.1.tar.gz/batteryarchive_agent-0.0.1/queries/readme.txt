python3 query_export.py --redash-url "<your URL>" --api-key "<your key>"
python3 query_import.py --redash-url "<your URL>" --api-key "<your key>"