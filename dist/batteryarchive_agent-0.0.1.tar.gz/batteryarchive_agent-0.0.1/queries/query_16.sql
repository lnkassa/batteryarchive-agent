/*
Name: Abuse Test DD
Data source: 1
Created By: admin
Last Update At: 2022-03-05T20:38:22.126Z
Visualizations: [{'id': 20, 'type': 'TABLE', 'name': 'Table', 'description': '', 'options': {}, 'updated_at': '2022-02-27T21:57:11.495Z', 'created_at': '2022-02-27T21:57:11.495Z'}]
*/

select cell_id from abuse_metadata order by cell_id