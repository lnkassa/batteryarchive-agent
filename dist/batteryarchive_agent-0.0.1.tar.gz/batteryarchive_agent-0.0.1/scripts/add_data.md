#
# Run from the project root folder
# To import sample abuse data: python3 ./scripts/data_import_agent.py -m add -t abuse -p /root/batteryarchive-agent/data/abuse/
# To import sample cycle data: python3 ./scripts/data_import_agent.py -m add -t cycle -p /root/batteryarchive-agent/data/cycle/

