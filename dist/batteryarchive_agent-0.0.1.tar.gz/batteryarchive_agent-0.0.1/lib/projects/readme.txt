This file:
1) Identifies capacitance check cycles.
2) Seperates these cycles into charge and discharge
3) Identifies charge cc and cv time and discahrge time in non capacity test cycles
4) calculates the charge and discharge capacity